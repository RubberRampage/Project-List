/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Random;
public class Main
{
	public static void main(String[] args) {
	    
    	Random rd = new Random(); // creating Random object
    	
        int[] arr = new int[50000];
        
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rd.nextInt(100000); // storing random integers in an array
             
        }
        
        // initializing 3 new arrays to be exactly like arr to use in the nest 3 sorts
        int b[] = new int[arr.length];
        int c[] = new int[arr.length];
        int d[] = new int[arr.length];
        int demo[] = new int[]{5, 8, 1, 3, 9, 6};
        
        
        for (int i = 0; i < arr.length; i++)
            b[i] = arr[i];
        for (int i = 0; i < arr.length; i++)
            c[i] = arr[i];
        for (int i = 0; i < arr.length; i++)
            d[i] = arr[i];
            
        InsertionSort.insertionSort(demo);
        
        // 1. Timing the Insertion Sort
        long startTime = System.nanoTime();    
        InsertionSort.insertionSort(arr);
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;
        System.out.println("Time taken by Insertion Sort: " + elapsedTime + " nanoseconds");
        System.out.println(" ");
        
        // 2. Timing Quick Sort
        long startTime2 = System.nanoTime();
        QuickSort.quicksort(b, 0, 49999);
        long endTime2 = System.nanoTime();
        long elapsedTime2 = endTime2 - startTime2;
        QuickSort.printQuick();
        System.out.println("Time taken by Quick Sort: " + elapsedTime2 + " nanoseconds");
        System.out.println(" ");
        
        // 3. Timing Heap Sort
        long startTime3 = System.nanoTime();
        HeapSort.heapSort(c);
        long endTime3 = System.nanoTime();
        long elapsedTime3 = endTime3 - startTime3;
        System.out.println("Time taken by Heap Sort: " + elapsedTime3 + " nanoseconds");
        System.out.println(" ");
        
        // 4. Timing Merge Sort
        long startTime4 = System.nanoTime();
        MergeSort.mergeSort(d, 0, 49999);
        long endTime4 = System.nanoTime();
        long elapsedTime4 = endTime4 - startTime4;
        MergeSort.printMerge();
        System.out.println("Time taken by Merge Sort: " + elapsedTime4 + " nanoseconds");
        
        // Printing the times for the Pre-Sorted Arrays
        System.out.println(" ");
        System.out.println("Sorted Arrays ");
        System.out.println(" ");
        
        long startTime5 = System.nanoTime();    
        InsertionSort.insertionSort(arr);
        long endTime5 = System.nanoTime();
        long elapsedTime5 = endTime5 - startTime5;
        System.out.println("Time taken by Insertion Sort: " + elapsedTime5 + " nanoseconds");
        System.out.println(" ");
        
        long startTime6 = System.nanoTime();
        QuickSort.quicksort(b, 0, 49999);
        long endTime6 = System.nanoTime();
        long elapsedTime6 = endTime6 - startTime6;
        QuickSort.printQuick();
        System.out.println("Time taken by Quick Sort: " + elapsedTime6 + " nanoseconds");
        System.out.println(" ");
        
        long startTime7 = System.nanoTime();
        HeapSort.heapSort(arr);
        long endTime7 = System.nanoTime();
        long elapsedTime7 = endTime7 - startTime7;
        System.out.println("Time taken by Heap Sort: " + elapsedTime7 + " nanoseconds");
        System.out.println(" ");
        
        long startTime8 = System.nanoTime();
        MergeSort.mergeSort(arr, 0, 49999);
        long endTime8 = System.nanoTime();
        long elapsedTime8 = endTime8 - startTime8;
        MergeSort.printMerge();
        System.out.println("Time taken by Merge Sort: " + elapsedTime8 + " nanoseconds");
        
        
        
        
        
	}
	
	
	
	
	
}
