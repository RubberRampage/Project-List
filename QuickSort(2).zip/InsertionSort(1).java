public class InsertionSort {
    public static void insertionSort(int[] arr) {
        int comparison = 0;
        int movement = 0;

        // Iterate over each element starting from the second one
        for (int i = 1; i < arr.length; i++) {
            int key = arr[i]; // Store the current element as key
            int j = i - 1; // Start comparing from the previous element

            // Compare with each element before the current element
            while (j >= 0) {
                comparison++; // Count comparison for j >= 0 check
                if (arr[j] > key) {
                    arr[j + 1] = arr[j]; // Shift element to the right
                    movement++; // Count movement for the shift
                    j--; // Move to the previous element
                } else {
                    break; // No further comparison if arr[j] <= key
                }
            }

            arr[j + 1] = key; // Place key in the correct position
            movement++; // Count movement for placing key
        }

        // Output total number of comparisons and movements
        System.out.println("Insertion Sort");
        System.out.println("Total comparisons: " + comparison);
        System.out.println("Total movements: " + movement);
    }
}


