public class HeapSort {
    private static int comparison = 0;
    private static int movement = 0;

    public static void heapSort(int[] arr) {
        int n = arr.length;

        // build the heap (rearrange the array)
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);  // heapify each non-leaf node
        }

        // extract elements from the heap one by one
        for (int i = n - 1; i > 0; i--) {
            // move the current root (largest) to the end
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // call heapify on the reduced heap
            heapify(arr, i, 0);
        }

        // print sorting results
        System.out.println("Heap Sort");
        System.out.println("Total comparisons: " + comparison);
        System.out.println("Total movements: " + movement);
    }

    private static void heapify(int[] arr, int n, int i) {
        // initialize largest as root
        int largest = i;
        int left = 2 * i + 1;  // left child
        int right = 2 * i + 2; // right child

        // compare left child with the largest element
        comparison++;
        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }

        // compare right child with the largest element
        comparison++;
        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }

        // if the largest is not the root, swap it with the root
        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            movement++;  // count the movement

            // recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }
}
