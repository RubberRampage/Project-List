public class QuickSort {

    // static counters for comparisons and movements
    static int comparisons = 0;
    static int movements = 0;

    // quick sort method
    public static void quicksort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);  // partition the array

            // recursively sort elements before and after partition
            if (pi - 1 > low) quicksort(arr, low, pi - 1);  // avoid unnecessary recursion
            if (pi + 1 < high) quicksort(arr, pi + 1, high);
        }
    }

    // median-of-three pivot selection to handle sorted or duplicate arrays
    private static int medianOfThree(int[] arr, int low, int high) {
        int mid = low + (high - low) / 2;
        if (arr[low] > arr[mid]) swap(arr, low, mid);   // compare low and mid
        if (arr[low] > arr[high]) swap(arr, low, high); // compare low and high
        if (arr[mid] > arr[high]) swap(arr, mid, high); // compare mid and high
        return mid;
    }

    // partition method with comparison and movement tracking
    private static int partition(int[] arr, int low, int high) {
        // use the median-of-three pivot strategy
        int pivotIndex = medianOfThree(arr, low, high);
        int pivot = arr[pivotIndex];

        // move pivot to the end for the standard partitioning
        swap(arr, pivotIndex, high);
        int i = low - 1;  // index of smaller element

        for (int j = low; j < high; j++) {
            comparisons++; // increment comparison counter
            if (arr[j] < pivot) {
                i++;
                swap(arr, i, j);  // swap elements
                movements++; // increment movement counter
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        swap(arr, i + 1, high);
        movements++; // count the final swap as a movement

        return i + 1;  // return the partition index
    }

    // utility function to swap two elements in an array
    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static void resetCounters() {
        comparisons = 0;
        movements = 0;
    }

    public static void printQuick() {
        System.out.println("Quick sort:");
        System.out.println("Total comparisons: " + comparisons);
        System.out.println("Total movements: " + movements);
    }
}