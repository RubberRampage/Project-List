public class MergeSort {

    private static int comparison = 0;
    private static int movement = 0;

    public static void mergeSort(int[] arr, int left, int right) {
        // check if there are elements to sort
        if (left < right) {
            // find the middle point
            int mid = (left + right) / 2;
            
            // recursively sort the left half
            mergeSort(arr, left, mid);
            
            // recursively sort the right half
            mergeSort(arr, mid + 1, right);
            
            // merge the sorted halves
            merge(arr, left, mid, right);
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        // calculate the size of two subarrays
        int n1 = mid - left + 1;
        int n2 = right - mid;
        
        // create temporary arrays for left and right halves
        int[] L = new int[n1];
        int[] R = new int[n2];

        // copy data to temporary arrays
        for (int i = 0; i < n1; i++) L[i] = arr[left + i];
        movement++; // track movements
        for (int j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];
        movement++; // track movements
        
        // merge the temporary arrays back into the original array
        int i = 0, j = 0;
        int k = left;
        
        // merge while both arrays have elements left
        while (i < n1 && j < n2) {
            comparison++; // track comparisons
            if (L[i] <= R[j]) {
                arr[k] = L[i]; // if left element is smaller
                i++;
            } else {
                arr[k] = R[j]; // if right element is smaller
                j++;
            }
            movement++; // track movements
            k++;
        }

        // copy remaining elements of L[], if any
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
            movement++; // track movements
        }

        // copy remaining elements of R[], if any
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    // method to print the total comparisons and movements
    public static void printMerge() {
        System.out.println("Merge Sort");
        System.out.println("Total comparisons: " + comparison);
        System.out.println("Total movements: " + movement);
    }
}
